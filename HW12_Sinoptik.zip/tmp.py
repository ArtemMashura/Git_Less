# парсинг сайтов
# жизненный цикл страницы
# - набор событый перед тем как она будет сформирована и отдена пользователю
# -
#  sinoptik.ua
import requests as requests
from bs4 import BeautifulSoup

# today-temp
selectClass = 'today-temp'
url = 'https://sinoptik.ua/%D0%BF%D0%BE%D0%B3%D0%BE%D0%B4%D0%B0-%D0%B4%D0%BD%D0%B5%D0%BF%D1%80-303007131'
htmlPage = requests.get(url)

#print(htmlPage.text)
#if htmlPage.status_code == 200:
#    soup = BeautifulSoup(htmlPage.text, 'html.parser')
    # методы
    # find по тегу - возврпащает первое вхождение
    # find п отегу и/или класс/айдишник
    # findAll  - возвращает все
#    res = soup.find('p', class_ =selectClass)
#    print(res)
#    print(res.text)
#else:
#    print('not 200')


# https://sinoptik.ua/%D0%BF%D0%BE%D0%B3%D0%BE%D0%B4%D0%B0-%D0%B4%D0%BD%D0%B5%D0%BF%D1%80-303007131
# запарсить блок - за последние 130 лет....
# макс темп ?? без года
# мин темп ??
#
#
#

def findVoshod(sss):
    fres = sss.find('div', class_='infoDaylight')

    #print(htmlElement.name, htmlElement.text)
    solnce = list()
    for span in fres.find_all('span'):
        solnce.append(span.text)
    print('восход = ', solnce[0], ' | закат = ', solnce[1])

def temp_min_max(sss):
    classFind = 'infoHistoryval'
    res_block = sss.find('p', class_=classFind)
    # print(res_block)

    flag_max = False
    flag_min = False
    max = 0
    min = 0

    for htmlElement in res_block.find_all():
        # print(htmlElement.name, htmlElement.text)

        if flag_max == True:
            max = htmlElement.text
            flag_max = False

        if flag_min == True:
            min = htmlElement.text
            flag_max = False

        if htmlElement.text == 'макс':
            flag_max = True
        if htmlElement.text == 'мин':
            flag_min = True
    print('MAX = ', max, ' | MIN = ', min)


def temp_for_day(sss):
    res_block = sss.find('div', class_='tabs')
    print(res_block)
    for div_block in res_block.find_all('div', class_='main'):
        print(div_block.text)

if htmlPage.status_code == 200:
    soup = BeautifulSoup(htmlPage.text, 'html.parser')
    #findVoshod(soup)
    #temp_min_max(soup)
    temp_for_day(soup)

else:
    print('not 200')


#
# время восхода и заката
# поендельник - теппартура - вторник - темп .....
#